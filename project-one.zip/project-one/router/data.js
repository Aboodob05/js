const lectures = [
    {
        'id' : 1,
        'name':'CS101',
        'major':'it',
        'instructorID':1
    },

    {
        'id' : 2,
        'name':'CIS202',
        'major':'it',
        'instructorID':2

    },

    {
        'id' : 3,
        'name':'Arabic101',
        'major':'HUM',
        'instructorID':3
    },
];

const instructors = [
    {
        'id' : 1,
        'name':'Ali',
        'age' : '45',
        'department': 'CS'
       
    },

    {'id' : 2,
        'name':'Ahmed',
        'age' : '50',
        'department': 'CIS'
       
    },

    {
        'id' : 3,
        'name':'Omar',
        'age' : '35',
        'department': 'BIT'
       
    },
];


module.exports = { lectures, instructors };
