
const express = require('express');

const router = express.Router();

const joi = require('joi');

const { instructors } = require('./data');

router.use(express.json());


router.get('/',(req,res)=>{
    res.send('Welcome to my page');
})


// router.get('/',(req,res)=>{
//     res.json(instructors);
// })


router.get('/:id',(req,res)=>{
    const inst = instructors.find((lec) => lec.id === parseInt(req.params.id));
    if (inst) {
        res.json(inst); 
    } 
    else {
        res.status(404).send('Lecture not found'); 
    }
});


router.post('/',(req,res)=>{

    const scm = joi.object({
    name: joi.string().min(3).required(),
    age: joi.number().required(),
    department: joi.string().min(2).required(),
    })


const {error} = scm.validate(req.body);
if(error){
    res.status(400).json(error.details[0].message)
}
    

   const inst = {
    id : instructors.length +1,
    age : req.body.age,
    name : req.body.name,
    department : req.body.department,
   }
   instructors.push(inst);
   res.status(200).json(inst);

})


router.put("/:id",(req,res)=>{
      const scm = joi.object({
       name: joi.string().min(5).required(),
       age: joi.number().required(),
       department: joi.string().min(3).required(),
    })

const {error} = scm.validate(req.body);
  if(error){
    res.status(400).json(error.details[0].message)
 }

const inst = instructors.find((lec) => lec.id === parseInt(req.params.id));
 if(inst){
    res.status(200).json(inst)
 }
 else{
    res.status(404).json("not found")
 }
  })


  router.delete("/:id",(req,res)=>{
    const inst = instructors.find((lec) => lec.id === parseInt(req.params.id));
    if(inst){
      res.status(200).json("deleted")
    }
    else{
      res.status(404).json("not found")
   }
 
  })

module.exports = router;
