

const express = require('express');
const app = express();
const joi = require('joi');
app.use(express.json());


const lecRouter = require("./router/lecture");
const instRouter = require("./router/instructors");
app.use('/lectures', lecRouter);
app.use('/instructors', instRouter);
const port = 3000;
app.listen(port,()=>console.log("done"));

